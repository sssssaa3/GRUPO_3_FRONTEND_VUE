# Equipo 

Integrantes:
- Sebastián Salas
- Carmen Castillo
- Stephanie Lobos 
- Silvia Cabello 

